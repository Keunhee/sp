# 파일 전체 컴파일 시
make clean
make

# board.c 단독 컴파일 시
make clean
make -f Makeboard

# board 단독 실행 시 
./board_alone

# client 단독 실행 시 
./client -ip {ip} -port {port} -username {username}